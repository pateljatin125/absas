 </div>
        <!-- END PAGE CONTAINER -->
        
        <!-- MESSAGE BOX-->
         <?php include('logout_messagebox.php'); ?>
        <!-- END MESSAGE BOX-->

        <!-- START PRELOADS -->
         <audio id="audio-alert" src="<?php echo base_url('assets/admin/audio/alert.mp3'); ?>" preload="auto"></audio>
        <audio id="audio-fail" src="<?php echo base_url('assets/admin/audio/fail.mp3'); ?>" preload="auto"></audio>        <!-- END PRELOADS -->             
        
    <!-- START SCRIPTS -->
        <!-- START PLUGINS -->
          <script type="text/javascript" src="<?php echo base_url('assets/admin/js/plugins/jquery/jquery.min.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/admin/js/plugins/jquery/jquery-ui.min.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/admin/js/plugins/bootstrap/bootstrap.min.js '); ?>"></script>              
        <!-- END PLUGINS -->
        
        <!-- THIS PAGE PLUGINS -->
        <script type='text/javascript' src='js/plugins/icheck/icheck.min.js'></script>
        <script type="text/javascript" src="js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
        
        <script type="text/javascript" src="js/plugins/bootstrap/bootstrap-datepicker.js"></script>                
        <script type="text/javascript" src="js/plugins/bootstrap/bootstrap-file-input.js"></script>
        <script type="text/javascript" src="js/plugins/bootstrap/bootstrap-select.js"></script>
        <script type="text/javascript" src="js/plugins/tagsinput/jquery.tagsinput.min.js"></script>
        <!-- END THIS PAGE PLUGINS -->       
        
        <!-- START TEMPLATE -->
        <script type="text/javascript" src="js/settings.js"></script>
        
        <script type="text/javascript" src="js/plugins.js"></script>        
        <script type="text/javascript" src="js/actions.js"></script>        
        <!-- END TEMPLATE -->
    <!-- END SCRIPTS -->                   
    </body>
</html>
