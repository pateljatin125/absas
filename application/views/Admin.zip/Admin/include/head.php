
<!DOCTYPE html>
<html lang="en">
    <head>        
        <!-- META SECTION -->
        <title>PSAS</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        
        <link rel="icon" href="<?php echo base_url('/assets/admin/'); ?>img/Vaaulogo1024.png" sizes="16x16 32x32" type="image/png">
        <!-- END META SECTION -->
                        
        <!-- CSS INCLUDE -->        
        <link rel="stylesheet" type="text/css" id="theme" href="<?php echo base_url('assets/admin/css/theme-default.css');?>"/>
        
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/admin/js/libs/common.js'); ?>"></script>
        <!-- EOF CSS INCLUDE -->                
    </head>
    <body>
	<input type="hidden" value="<?php echo base_url(); ?>" name="bseurl" class="table_input" id="bseurl"  />
        <!-- START PAGE CONTAINER -->
        <div class="page-container">