<div class="btn-group pull-right">
                                        <button class="btn btn-danger dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i> Export Data</button>
                                        <ul class="dropdown-menu">
                                            
                                           
                                           
                                            <!--<li><a href="#" onClick ="$('#customers2').tableExport({type:'csv',escape:'false'});"><img src=<?php echo base_url();?>assets/admin/img/icons/csv.png width="24"/> CSV</a></li>-->
                                            
                                            <!--<li class="divider"></li>-->
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'excel',escape:'false'});"><img src=<?php echo base_url();?>assets/admin/img/icons/xls.png width="24"/> XLS</a></li>
                                            <!--<li><a href="#" onClick ="$('#customers2').tableExport({type:'doc',escape:'false'});"><img src=<?php echo base_url();?>assets/admin/img/icons/word.png width="24"/> Word</a></li>-->
                                            
                                            
                                        </ul>
                                    </div>  