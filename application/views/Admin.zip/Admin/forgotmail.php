<?php 

echo base_url('AdminUpdateLink/').$otp;

?>

