<?php include('include/header.php'); ?>
<link rel="stylesheet" type="text/css" id="theme" href="<?php echo base_url('assets/css/managedata.css'); ?>" />
<div class="page-container">
    <?php include('include/left_side.php'); ?>
    <div class="page-content">
        <?php include('include/top_nav.php'); ?>
        <div class="page-content-wrap">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title"><strong>Emergency Numbers Management</strong></h3>
                            <?php if (isset($_SESSION['userAdd'])) { ?>
                                <div class="alert alert-success"><?php echo $_SESSION['userAdd'] ?></div>
                            <?php }
                            if (isset($_SESSION['usernotAdd'])) { ?>
                                <div class="alert alert-danger"><?php echo $_SESSION['usernotAdd'] ?></div>
                            <?php } ?>
                            <div class="btn-group pull-right">
                                <button class="btn btn-danger dropdown-toggle" data-toggle="modal" data-target="#exampleModal2"><i class="fa fa-bars"></i>Create Officer Unit</button>
                            </div>
                            <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Create Officer Unit
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button></h5>
                                        </div>
                                        <form id="CreateOfficerUnit" action="<?php echo base_url('CreateOfficerUnit'); ?>" role="form" class="form-horizontal" method="POST" enctype="multipart/form-data">
                                            <div class="modal-body">
                                                <div class="col-md-12 mt-3" style="padding:30px 15px; background:#fff">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="panel panel-default">
                                                                <div class="panel-body">
                                                                    <div class="row">
                                                                        <div class="form-group">
                                                                            <label class="col-md-3 control-label">LGA</label>
                                                                            <div class="col-md-9">
                                                                                <div class="input-group">
                                                                                    <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                                                                    <input type="hidden" class="form-control" name="ZONE" id="ZONE" required />
                                                                                    <select class="form-control" name="State" id="State" required>
                                                                                        <option value=" ">Select LGA</option>
                                                                                        <?php foreach ($state_new as $itm) { ?>
                                                                                            <option class="<?php echo $itm['Zone']; ?>" value="<?php echo $itm['LGA']; ?>"><?php echo $itm['LGA']; ?></option>
                                                                                        <?php } ?>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-md-3 control-label">Agency</label>
                                                                            <div class="col-md-9">
                                                                                <div class="input-group">
                                                                                    <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                                                                    <select class="form-control" name="emergency_type_id" id="emergency_type_id" required>
                                                                                        <option value="">Select Unit Type</option>
                                                                                        <?php foreach ($unit_types as $itm) { ?>
                                                                                            <option value="<?php echo $itm['PoliceUnitType_id']; ?>"><?php echo $itm['PoliceUnitType_name']; ?></option>
                                                                                        <?php } ?>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-md-3 control-label">Number</label>
                                                                            <div class="col-md-9">
                                                                                <div class="input-group">
                                                                                    <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                                                                    <input type="text" class="form-control" name="NUM" id="NUM" required />
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <input type="Submit" class="btn btn-primary pull-left" value="Submit" />
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="panel-body">
                            <div class="panel panel-default tabs">
                                <div class="panel-body tab-content">
                                    <div class="tab-pane active" id="tab1">
                                        <table id="customers2" class="table datatable">
                                            <thead>
                                                <tr>
                                                    <th>SrNo.</th>
                                                    <th>Emergency ID</th>
                                                    <th>State</th>
                                                    <th>Number</th>
                                                    <th>Unit Type</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $count = 1;
                                                foreach ($result as $itm) { ?>
                                                    <tr class='' id="OfficerUnit<?php echo $itm['EMERGENCY_id']; ?>">
                                                        <td><?php echo $count; ?>.</td>
                                                        <td><?php echo $itm['EMERGENCY_id']; ?></td>
                                                        <td><?php echo $itm['STATE']; ?></td>
                                                        <td><?php echo $itm['NUM']; ?></td>
                                                        <td><?php echo $itm['PoliceUnitType_name']; ?></td>
                                                        <td>
                                                            <a href="#" data-toggle="modal" data-target="#exampleModal1" onclick="return OfficerUnitupdate(<?php echo $itm["EMERGENCY_id"]; ?>)">Edit/</a>
                                                            <a href="javascript:void(0)"><span onClick="return doconfirm(<?php echo $itm['EMERGENCY_id']; ?>);">Delete/</span></a>
                                                            <a href="#" data-toggle="modal" data-target="#exampleModal" onclick="return OfficerUnitview(<?php echo $itm["EMERGENCY_id"]; ?>)">View</a>
                                                        </td>
                                                    </tr>
                                                <?php $count++;
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Update Officer Unit
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button></h5>
                                </div>
                                <form id="UpdateOfficerUnit" action="<?php echo base_url('UpdateOfficerUnit'); ?>" role="form" class="form-horizontal" method="POST" enctype="multipart/form-data">
                                    <div class="modal-body">
                                        <div class="col-md-12 mt-3" style="padding:30px 15px; background:#fff">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="row" id="modal_body1">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <input type="Submit" class="btn btn-primary pull-left" value="Update" />
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Officer Unit Details
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button></h5>
                                </div>
                                <div class="modal-body">
                                    <div class="col-md-12 mt-3" style="padding:30px 15px; background:#fff">
                                        <div class="row" id="modal_body">
                                            ...
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include('include/mange_script.php'); ?>
    <script>
        $("#State").change(function() {
            // var end = this.value;                
            var end = $('select[name="State"] :selected').attr('class');
            $("#ZONE").attr('value', end);
        });

        $("#edState").change(function() {
            var end = $('select[name="edState"] :selected').attr('class');
            $("#edZONE").attr('value', end);
        });

        function OfficerUnitview(EMERGENCY_id) {
            var base_url = $('#base_url').val();
            var datastring = 'EMERGENCY_id=' + EMERGENCY_id;
            $.ajax({
                url: base_url + 'Admin/OfficerUnitview',
                method: 'POST',
                data: datastring,
                success: function(response) {
                    $("#modal_body").html(response);
                }
            });
        }

        function OfficerUnitupdate(EMERGENCY_id) {
            var base_url = $('#base_url').val();
            var datastring = 'EMERGENCY_id=' + EMERGENCY_id;
            $.ajax({
                url: base_url + 'Admin/OfficerUnitEdit',
                method: 'POST',
                data: datastring,
                success: function(response) {
                    $("#modal_body1").html(response);
                }
            });
        }


        function doconfirm(id) {
            job = confirm("Are you sure to delete permanently?");
            if (job != true) {
                return false;
            }
            var base_url = $('#base_url').val();
            var datastring = 'EMERGENCY_id=' + id;
            $.ajax({
                url: base_url + 'Admin/OfficerUnitdel',
                method: 'POST',
                data: datastring,
                success: function(data) {
                    $('#OfficerUnit' + id).remove();
                }
            });
        }

        function changeBannerStatus(status, event_id) {
            var base_url = $('#base_url').val();
            var datastring = 'status=' + status + '&SOSid=' + event_id;
            $.ajax({
                url: base_url + 'Admin/SOSStatus',
                method: 'POST',
                data: datastring,
                success: function(data) {
                    if (data == 1) {
                        $('#status_' + event_id).html('<a href="javascript:void(0);" onclick="changeBannerStatus(0,' + event_id + ')"><img src=' + base_url + 'images/bullet_green.png width="32" height="32" title="click to deactive this banner." /></a>');
                    } else {
                        $('#status_' + event_id).html('<a href="javascript:void(0);" onclick="changeBannerStatus(1,' + event_id + ')"><img src=' + base_url + 'images/bullet_red.png width="32" height="32" title="click to Aeactive this banner." /></a>');
                    }
                }
            });
        }

        function addlocation() {
            $('#adt').append('<div class="form-group"  id="PatrolLocations"><label class="col-md-3 control-label">Patrol Locations</label><div class="col-md-9"><div class="input-group"><span class="input-group-addon"><span class="fa fa-pencil"></span></span><input type="text" class="form-control" name="PatrolLocations[]" id=""  /></div></div></div>');
        }
    </script>
    </body>

    </html>